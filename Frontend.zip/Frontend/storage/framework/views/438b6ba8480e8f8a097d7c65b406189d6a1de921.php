    <hr>
    </body>
</html><?php /**PATH C:\Users\malus\Frontend\resources\views/componentes/footer.blade.php ENDPATH**/ ?>