<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor de Tareas</title>
</head>
<body>
    <h1>Bienvenido al Gestor de Tareas</h1>
    <p>Aquí puedes gestionar tus tareas de manera eficiente.</p>
</body>
</html><?php /**PATH C:\Users\malus\Frontend\resources\views//tareas.blade.php ENDPATH**/ ?>