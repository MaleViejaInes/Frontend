<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Gestor de tareas</title>
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    
</head>
<body>
    
    <div class="navbar">
        <a href="/">Inicio</a>
        <a href="/login">Iniciar sesión</a>
        <a href="/registrar">Registrar usuario</a>
        <a href="/tareas">Tareas</a>
    </div>
    
    <div class="buscar-tarea">
        <h2>¿Deseas encontrar una tarea?</h2>
        <form action="/buscarTarea" method="GET">
            <input type="text" name="query" placeholder="Ingresa el ID" required>
            <button type="submit">Buscar</button>
        </form>
    </div>
    
    <div class="mostrar-tareas">
        <h2>A continuación se muestran las tareas previamente creadas:</h2>
        <div>
            
        </div>

    </div>
    
</body>
</html>
        



<?php /**PATH C:\Users\malus\Frontend\resources\views/principal.blade.php ENDPATH**/ ?>