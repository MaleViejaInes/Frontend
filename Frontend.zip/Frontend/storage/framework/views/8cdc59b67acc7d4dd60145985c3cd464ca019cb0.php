<!DOCTYPE html>
<html>
<head>
    <title>Página Principal</title>
</head>
<body>
    <h1>logueate pa</h1>
    <form action="/loguearUsuario" method="POST">
    <?php echo csrf_field(); ?>
    <input type="email" name="email" placeholder="Correo" required><br>
    <input type="password" name="password" placeholder="Contraseña" required><br>
    <button type="submit">Ingresar</button>
</form>

    <p>¿No tienes cuenta? <a href="/registro">Regístrate aquí</a></p>
    
    <?php if(session('error')): ?>
        <script>
        alert("<?php echo e(session('error')); ?>");
        </script>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\malus\Frontend\resources\views/login.blade.php ENDPATH**/ ?>