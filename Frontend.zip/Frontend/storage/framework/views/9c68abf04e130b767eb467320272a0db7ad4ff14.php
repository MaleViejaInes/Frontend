<html>
    <head>
        <title>Pagina</title>
        
    </head>
    <body>

    <nav>   
        <ul>
            <li><a href="/">Inicio</a></li>
            <li><a href="/privado">Privado</a></li>
            <?php if(Auth::check()): ?>
                <li><?php echo e(Auth::user()->name); ?></li>
                <li><a href="/logout">Logout</a></li>
            <?php else: ?>
                <li><a href="/login">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <hr><?php /**PATH C:\Users\malus\Frontend\resources\views/componentes/header.blade.php ENDPATH**/ ?>